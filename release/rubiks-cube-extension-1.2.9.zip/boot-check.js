// Diagnostic surface: shows any boot failure instead of a blank screen.
(function () {
  var shown = false;
  function show(title, detail) {
    if (shown) return;
    shown = true;
    var box = document.createElement('div');
    box.style.cssText =
      'position:fixed;inset:0;z-index:9999;display:flex;align-items:center;' +
      'justify-content:center;background:#0b0b16;color:#ff8fa3;font:13px/1.6 monospace;' +
      'padding:24px;white-space:pre-wrap;overflow:auto';
    var inner = document.createElement('div');
    var heading = document.createElement('div');
    heading.style.cssText = 'font-size:16px;color:#fff;margin-bottom:10px';
    heading.textContent = title;
    var message = document.createElement('div');
    message.style.color = '#ffd166';
    message.textContent = detail || '';
    inner.appendChild(heading);
    inner.appendChild(message);
    box.appendChild(inner);
    document.documentElement.appendChild(box);
  }
  window.__cubeFail = show;

  window.addEventListener('error', function (e) {
    show('Script error', (e.message || '') + '\n' + (e.filename || '') + ':' + (e.lineno || ''));
  }, true);
  window.addEventListener('unhandledrejection', function (e) {
    var r = e.reason;
    show('Failed to load module', r && r.message ? r.message : String(r));
  });

  // WebGL availability check
  try {
    var c = document.createElement('canvas');
    var gl = c.getContext('webgl2') || c.getContext('webgl');
    if (!gl) show('WebGL unavailable', 'Enable hardware acceleration in browser settings.');
  } catch (err) {
    show('WebGL check failed', String(err));
  }

  // Flag if the bundle never finishes booting
  window.__cubeBooted = false;
  setTimeout(function () {
    if (!window.__cubeBooted) {
      show('Cube did not start', 'cube.bundle.js failed to run.\n' +
        'Check that extension/cube.bundle.js exists and extension/cube.html\n' +
        'loads it with <script src="cube.bundle.js">.');
    }
  }, 8000);
})();
